#!/bin/bash

apt -y install rdiff-backup inotify-tools rsync