#!/bin/bash

su backupr -c "./backup/manual-backup.sh /opt/backup/encrypt /opt/CA /opt/backup/enc/CA /opt/backup/tmp/CA aes-256-cbc /opt/backup/aes-256.key"